'use strict'

require('./cli')
require('./http-api')
require('./gateway')
// require('./core') // get automatically picked up
