'use strict'

module.exports = {
  gateway: require('./gateway')
}
