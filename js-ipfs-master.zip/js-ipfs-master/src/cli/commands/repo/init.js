'use strict'

module.exports = {
  command: 'init',

  describe: '',

  builder: {},

  handler (argv) {
  }
}
