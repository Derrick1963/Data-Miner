'use strict'

module.exports = {
  command: 'gc',

  describe: '',

  builder: {},

  handler (argv) {
  }
}
