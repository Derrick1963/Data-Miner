'use strict'

module.exports = {
  command: 'unwant <key>',

  describe: 'Remove a given block from your wantlist.',

  handler (argv) {
    throw new Error('Not implemented yet')
  }
}
