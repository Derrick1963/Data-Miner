# Bundle js-ipfs with Webpack!

> In this example, you will find a boilerplate you can use to guide yourself into bundling js-ipfs with webpack, so that you can use it in your own web app!

## Run this example

Once the daemon is on, run the following commands within this folder:

```bash
> npm install
> npm start
```

Now open your browser at `http://localhost:3000`

You should see the following:

![](https://ipfs.io/ipfs/QmZndNLRct3co7h1yVB72S4qfwAwbq7DQghCpWpVQ45jSi/1.png)
