# js-ipfs in Electron

> This example is heavily inspired by [electron-quick-start](https://github.com/electron/electron-quick-start).

**DISCLAIMER:** This example is still a work in progress, it currently doesn't work due to the usage of native dependencies that Electron is not supporting.

To try it by yourself, do:

```
> npm install
> ./node_modules/.bin/electron-rebuild
# or 
> ./build.sh
#
# You can also try to use `npm start` to see where electron errors
```
