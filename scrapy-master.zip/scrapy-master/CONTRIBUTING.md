The guidelines for contributing are available here:
https://doc.scrapy.org/en/master/contributing.html

Please do not abuse the issue tracker for support questions.
If your issue topic can be rephrased to "How to ...?", please use the
support channels to get it answered: https://scrapy.org/community/
