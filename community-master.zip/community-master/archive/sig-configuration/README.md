This group is for discussion about application configuration and deployment in Kubernetes. We use the label `area/app-config-deployment` to tag related issues and pull requests on Github. 

For Kubernetes cluster configuration and deployment, see [SIG-Cluster-Ops](SIG-Cluster-Ops).

[Google group](https://groups.google.com/forum/#!forum/kubernetes-sig-config)

[Slack](https://kubernetes.slack.com/messages/sig-configuration/)

For access to the meeting agenda and notes, please join the Google group.
* [Meeting Agenda and Notes](https://docs.google.com/document/d/1FZ_jiOdBZ_bfPD5Y3QMcfs2SCx956QLc9_E0QdR_l20/edit)

