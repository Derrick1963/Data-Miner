# What is the role of a sig lead
*Notetaker: @MHBauer*  
Lots of sig leads are present in the room

If there is a doc it’s years out of date

Joe wants to redefine the session
Power and role of sig leads is defined in how we pick these people. Voting?  Membership? What do we do for governance in general


Paul: Roles that are valuable that are not sig lead. Svc cat, moderator of discussions and took notes. Secretary of committee. 

Back to joe; what does the sig think. Each leader doesn’t know. Who shows up to a meeting isn’t helpful as not everyone can attend. What does the lead thing? Allows too much personal power. Decision maker or tech lead? 

Meeting form last year is that sig lead was facilitator. Have been more tech leads now.  Sig leads got invites to the contributor summit. 

Erik from testing. Failures in tests associated with a sig lead to no accountability by a sig member. Assigned the label to the sig with no action afterwards. Need accountability from the sigs or the leads to get testing failures cleared

Owners files, maintainers, approvers, of particular parts of the code base. As a sig lead. Mostly doing facilitating, and not touching the code. Owners files own the codebase. Not the leads of the sigs. Sig leads elevate problems to the people in the owners files. 

Daniiel smith - api - would not be helpful to have a facilitator, mostly very technical details.

Paul, tech vs facilitator fulls you in different directions. Facilitator with an agenda is a dictator. If you have a tech agenda, you should not try to lead all the meetings. Meeting facilitator role that aaron did, operated the meeting agenda. Hands to talk. Stopped advocating for techical topics, and mainly doing moderation. Everyone else focuses on technical topics. 

Joe - 3 roles, process facilitatior, technical facilictator, techincal design and lead. Implication that the process leader is not technical. Build consensus vs “we’re doing it this way” 

Down - on sig node. Facilitatior and tech lead. Detach from. If she doesn’s make the agenda there is not one. 

Joe -need someone who cares

Eric chang - every sig needs a person doing X,Y, Z. docs, tests, etc. fundamental goals. Sig lead has too much to do. Formalize roles and fill them with people, especially different people for each role. 
Large sigs have more people to allocate to alt roles.

Jessie - Can’t have the person who facilitates be unbiased technically. Best solution vs alternative monetary gain.

Joe -  people as sig leads in name only to game the system as being important

Erik - adding or retiring members. 

Do any sigs have an election process? Not that we know of. Sig node has a rotation. One member retired as they moved from working on the open source to working on their internal system. Some people turned down a lead, based on the involvememt necessary. 

Sig leads should already should be fulfilling the role, vs assigning titles and duties to expect 

Define roles, and all sigs must provide names. 

Document process for how to choose role. Fair and equitable. A generic process that’s generic. 

People in the sig decide. Who’s in the sig? How do we say a sig or sig member is doing a bad job?

How to decide who gets to decide?

Which things does a sig own. People own things, not sigs. With a document proposed to assess new owners. Subteams and persons. 

People who have non-code duties, but are also still participants and lead-worthy.

 Does sig-pm write any code? 

Long term sigs own artifacts. They own process and have long term documentation.

Things not in kubernetes/kubernetes don’t have necessarily an ownersfile. 

Everything should role up to a sig.

Owners cut across a project and end up having a person with lots of power vs a sig. 

Sigs and humans as owners.

Erik f - Tests assigned to owners seems to be a fialure. A sig having a dashboard seems successful. The sig being responsible seems successful, not a person responsible. Things assigned to sigs, not to people.

Suggestion of a person on a single sig. Limits. Pick what you find important, commit to it. 
Might be career limiting if you can olnly work on one thing. 
Doubts of same person leading multiple sigs.
Leading a sig vs participating. 
Multiple roles again.

Sig lead, to facilitate, sig pm representative to put technical demands and objectives to the wider community.
What to do when they fail?
Separation of powers. Do we have it now? Are the people who lead a meeting the people who code and merge and approve.

Joe - gut check summary
Set of roles to nominate
Clear lines of sight which owns what code
Some are large and may have subdivisions (do people own code or do groups)
Starting point for sigs
Everyone should document the process and how it got that way
Possible future date to reboot the sigs. Evolution vs revolution. Merge and split.
Sig lead retired in frvor of multiple roles. “Lead” creates perverse incentives. Roles with terrible titles. POLITICS!

Find a set of roles. 

What’s the bar to form a sig?
If I want to have a component, I need a sig! 

Retire and merge some sigs. Sig for each cloud and a common cloudprovider and a cross-cloud sig.
Cluster-lifecycle plus cluster-ops

Daniel - avoid selecting process followers, not for decision making skills. Avoid over specifying.

Joe - We need to expect some responsibility from the sig to the rest of the project. Avoid overfit.

Associate owners files with sigs, maintainers vs sig leads. Contributor ladder is disorganized. Owners contributors maintainers. 

4 minutes. 
Work with the steering committee to work this out. Steeering committee has to do this to help this make. 

Hard to participate in some sigs, 
Suggestion of office hours

Spotty communication of what a sig is doing. Authority and responsibility of what to communicate what a sig is doing.

