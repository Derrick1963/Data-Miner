**NOTE:** This document has moved to [a new location](communication/).
