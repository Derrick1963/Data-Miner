## SIG creation procedure

Moved to [sig governance](/sig-governance.md#sig-creation-procedure)
