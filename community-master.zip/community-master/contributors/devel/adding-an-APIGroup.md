Adding an API Group
===============

Please refer to [api_changes.md](api_changes.md#making-a-new-api-group).
