+**NOTE:** This document has moved to [a new location](/contributors/guide/issue-triage.md)
