# Document Conventions

Updated: 11/3/2017

*Users and developers who want to write documents for Kubernetes can get started [here](https://github.com/kubernetes/website).*
