This page has moved to:

https://git.k8s.io/community/contributors/guide/
