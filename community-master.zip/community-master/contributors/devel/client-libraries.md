## Kubernetes API client libraries

This document has been moved to https://kubernetes.io/docs/reference/client-libraries/.
