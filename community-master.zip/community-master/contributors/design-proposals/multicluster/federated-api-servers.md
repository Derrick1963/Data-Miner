# Federated API Servers

Moved to [aggregated-api-servers.md](../api-machinery/aggregated-api-servers.md) since cluster
federation stole the word "federation" from this effort and it was very confusing.
