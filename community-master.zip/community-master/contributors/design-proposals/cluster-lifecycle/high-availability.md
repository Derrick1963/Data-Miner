# High Availability of Scheduling and Controller Components in Kubernetes

This document is deprecated. For more details about running a highly available
cluster master, please see the [admin instructions document](https://kubernetes.io/docs/admin/high-availability/).
