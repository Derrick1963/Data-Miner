# Welcome to KubeCon Copenhagen's New Contributor Track!

Hello new contributors!

This subfolder of [kubernetes/community](https://github.com/kubernetes/community) will be used as a safe space for participants in the New Contributor Onboarding Track to familiarize themselves with (some of) the Kubernetes Project's review and pull request processes.

The label associated with this track is `area/new-contributor-track`.

*If you are not currently attending or organizing this event, please DO NOT create issues or pull requests against this section of the community repo.*

A [Youtube playlist](https://www.youtube.com/playlist?list=PL69nYSiGNLP3M5X7stuD7N4r3uP2PZQUx) of this workshop has been posted, and an outline of content to videos can be found [here](http://git.k8s.io/community/events/2018/05-contributor-summit).

