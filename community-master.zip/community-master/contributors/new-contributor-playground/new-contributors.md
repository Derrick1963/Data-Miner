# Hello everyone!

Please feel free to talk amongst yourselves or ask questions if you need help

First commit at kubecon from @mitsutaka