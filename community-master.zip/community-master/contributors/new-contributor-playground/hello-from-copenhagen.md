# Hello from Copenhagen!

Hello everyone who's attending the Contributor Summit at KubeCon + CloudNativeCon in Copenhagen!
Great to see so many amazing people interested in contributing to Kubernetes :)
