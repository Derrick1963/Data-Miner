This directory contains theme files from the free version of Pixelkit's
Dark Velvet Bootstrap UI kit, which is licensed under the MIT License:
http://opensource.org/licenses/mit-license.html.

This directory should be populated with the following content:

  css/*
  fonts/*
  images/*

These files can be found on github at:

https://github.com/Pixelkit/PixelKit-Bootstrap-UI-Kits/tree/master/dark-velvet/dark-velvet-css

The current build uses commit 2aa3a52c09, Jan 24, 2014.
