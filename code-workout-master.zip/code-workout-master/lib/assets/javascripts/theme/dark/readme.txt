This directory contains theme files from the free version of Pixelkit's
Dark Velvet Bootstrap UI kit, which is licensed under the MIT License:
http://opensource.org/licenses/mit-license.html.

This directory should be populated with the complete contents of the following folder:

https://github.com/Pixelkit/PixelKit-Bootstrap-UI-Kits/tree/master/dark-velvet/dark-velvet-css/js

The current build uses commit 0cd5d01152, Nov 11, 2013.
