# Be sure to restart your server when you modify this file.

CodeWorkout::Application.config.session_store :cookie_store, key: '_code-practice_session'
