# Exception Handler
###
# You can add different settings using this block
# Use the docs at http://github.com/richpeck/exception_handler for info
###
ExceptionHandler.setup do |config|
	config.db = true
end
