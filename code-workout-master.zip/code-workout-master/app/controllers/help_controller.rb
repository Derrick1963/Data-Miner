class HelpController < ApplicationController
  layout 'application'

  def index
  end

  def exercise_format
  end

  def lti_configuration
  end

end
