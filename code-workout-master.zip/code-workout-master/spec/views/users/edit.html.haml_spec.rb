require 'spec_helper'

describe "users/edit.html.haml" do
  pending "add some examples to (or delete) #{__FILE__}"
end
