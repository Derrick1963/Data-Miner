require 'spec_helper'

describe "users/index.html.haml" do
  pending "add some examples to (or delete) #{__FILE__}"
end
