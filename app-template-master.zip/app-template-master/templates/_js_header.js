/*
 * Looking for the full, uncompressed source? Try here:
 *
 * https://github.com/nprapps/{{ REPOSITORY_NAME }}
 *
 * The following files are included in this compressed version:
 *{% for path in paths %}
 * {{ path }}{% endfor %}
 */
