// Global jQuery references

/*
 * Run on page load.
 */
var onDocumentLoad = function(e) {
    // Cache jQuery references
    renderExampleTemplate();
}

/*
 * Basic templating example.
 */
var renderExampleTemplate = function() {
    var context = $.extend(APP_CONFIG, {
        'template_path': 'jst/example.html',
        'config': JSON.stringify(APP_CONFIG, null, 4),
        'copy': JSON.stringify(COPY, null, 4)
    });

    var html = JST.example(context);

    $('#template-example').html(html);
}

$(onDocumentLoad);
