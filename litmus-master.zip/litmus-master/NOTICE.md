The source code developed for the OpenEBS Project is licensed 
under Apache 2.0. 

However, the OpenEBS project contains unmodified/modified 
subcomponents from other OpenSource Projects with separate
copyright notices and license terms. 

Your use of the source code for these subcomponents is subject
to the terms and conditions as defined by those source projects.
