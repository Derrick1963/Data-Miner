The provider contains playbooks to setup storage providers on the Kubernetes cluster. This may involve installing Operators,
static provisioning of disk resources (say, Kubernetes Local Persistent Volume), or cloud storage (Google persistent disks).

The playbook may be self-contained, i.e., consist of all steps required to setup the storage provider or can invoke a role 
created for that purpose




 
