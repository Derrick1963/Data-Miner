# Ansible Plugins
-----------------

Contains custom plugins that can be integrated into Ansible. Currently holds the callback plugin which has been modified 
to hide/suppress certain messages during failed retries in a loop-execution. 

