The utils folder is a collection of ansible taskfiles which are written with a view : 

- To modularize the playbooks themselves & reuse common tasks which can be invoked with appropriate arguments
- To abstract complex tasks from the playbook, thereby enabling users to simply "call" a routine while extending the executor


