# Generate disk io's

## This script will read from and write into same file concurrently. You can change file names to perform read-write operation on different files.
