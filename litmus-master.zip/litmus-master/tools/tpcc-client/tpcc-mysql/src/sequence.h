/*
 * sequence.h
 */

void seq_init( int n, int p, int o, int d, int s );
int seq_get();
