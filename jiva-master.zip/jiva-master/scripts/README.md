The following launch scripts are wrappers around the docker command.
- launch-jiva-ctl-with-ip
- launch-jiva-rep-with-ip

Using the env parameters passed to the scripts, the IP address is created on the docker host and passed to the docker containers. 

The docker wrapper scripts have been inspired from https://github.com/FRosner/nomad-docker-wrapper. 

