from distutils.core import setup

setup(
    name='Longhorn Integration Tests',
    version='0.1',
    packages=[
      'core',
      'data',
    ],
    license='ASL 2.0',
)
